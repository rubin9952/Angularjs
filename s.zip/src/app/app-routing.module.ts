import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistartionComponent } from './registartion/registartion.component';
 const routes : Routes =[
   {path : 'registartion' ,component :RegistartionComponent  },
   {
     path :'login',component :LoginComponent
   }

 ];
@NgModule({
  imports :[RouterModule.forRoot(routes)],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
export const routingcomponents=[RegistartionComponent,LoginComponent]