import { Component, OnInit } from '@angular/core';
import { NgForm} from '@angular/forms';

@Component({
  selector: 'app-registartion',
  templateUrl: './registartion.component.html',
  styleUrls: ['./registartion.component.css']
})
export class RegistartionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  
    
  }
  saveuser(regform : NgForm)
  {
    {
      console.log(regform.value);
    }
  }

}
